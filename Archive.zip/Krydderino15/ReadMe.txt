
  Krydderino15
  Project
  ----------------------------------
  Developed with embedXcode

  Project Krydderino15
  Created by Haakon Storm Heen on 21.05.13
  Copyright © 2013 Haakon Storm Inc
  Licence CC = BY SA NC


  References
  ----------------------------------



  embedXcode
  ----------------------------------
  Embedded Computing Template on Xcode 4
  Copyright © Rei VILO, 2010-2013
  Licence CC = BY NC SA
  http://embedXcode.weebly.com/

