	
	embedXcode
	----------------------------------
	Embedded Computing on Xcode 4


	© Rei VILO, 2010-2013
	CC = BY NC SA

	• Website
	http://embedXcode.weebly.com

	• Documentation
	http://embedXcode.weebly.com/tutorial

	• Installation package
	http://embedXcode.weebly.com/download

	• GitHub repository
	https://github.com/rei-vilo/embedXcode
	
	

Installation
----------------------------------
Launch the embedXcode installation package


Contributions
----------------------------------
See attached documents for detailed references


----------------------------------
End of file

